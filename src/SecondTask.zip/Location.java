public record Location(String regionName, String districtName, Integer homeNumber) {
}
